package net.futureclient.client;

public enum TD {
    f$M,
    f$g;


    /*
     * WARNING - Possible parameter corruption
     * WARNING - void declaration
     */
    private TD() {
        TD tD;
    }
}
package net.futureclient.client;

import net.futureclient.client.RF;

public class Td
extends RF {
    public Td() {
        Td td;
    }
}
package net.futureclient.client;

import net.futureclient.client.kB;
import net.futureclient.client.sC;

public class td
extends kB {
    public final sC f$d;

    @Override
    public void f$E() {
        td td2;
        td2.f$d.f$d.f$E(Float.valueOf(3.5f));
    }

    public td(sC sC2, String string) {
        0.f$d = sC2;
        super(string);
    }
}
package net.futureclient.client;

public enum tD {
    f$i,
    f$M,
    f$g;


    /*
     * WARNING - Possible parameter corruption
     * WARNING - void declaration
     */
    private tD() {
        tD tD2;
    }
}
