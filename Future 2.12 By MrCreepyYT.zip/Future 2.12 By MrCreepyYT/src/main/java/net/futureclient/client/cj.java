package net.futureclient.client;

import net.futureclient.client.Ha;
import net.futureclient.client.Pf;
import net.futureclient.client.fi;

public class cj
extends Ha<Pf> {
    public final fi f$d;

    @Override
    public void f$E(Pf pf) {
        if (fi.f$B((fi)0.f$d).player.func_110143_aJ() <= 0.0f) {
            cj cj2 = 0;
            fi.f$e(cj2.f$d, fi.f$e((fi)cj2.f$d).player.field_70165_t);
            cj cj3 = 0;
            fi.f$a(cj3.f$d, fi.f$a((fi)cj3.f$d).player.field_70163_u);
            cj cj4 = 0;
            fi.f$E(cj4.f$d, fi.f$E((fi)cj4.f$d).player.field_70161_v);
        }
    }

    public cj(fi fi2) {
        0.f$d = fi2;
    }
}
