package net.futureclient.client;

import net.futureclient.client.Vf;
import net.futureclient.client.kF;

public class Ef {
    public static final int[] f$d;
    public static final int[] f$g;

    static {
        f$d = new int[kF.values().length];
        try {
            Ef.f$d[kF.f$M.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        f$g = new int[Vf.values().length];
        try {
            Ef.f$g[Vf.f$M.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Ef.f$g[Vf.f$g.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
    }
}
package net.futureclient.client;

import net.futureclient.client.Ba;
import net.futureclient.client.CF;
import net.futureclient.client.JD;
import net.futureclient.client.Qe;
import net.futureclient.client.ka;

public final class EF
extends Ba {
    private final ka<CF> f$d;

    public EF() {
        EF eF;
        String[] stringArray = new String[3];
        stringArray[0] = "Swing";
        stringArray[1] = "NoSwing";
        stringArray[2] = "OffhandSwing";
        super("Swing", stringArray, true, -103, JD.f$K);
        EF eF2 = eF;
        String[] stringArray2 = new String[2];
        stringArray2[0] = "Mode";
        stringArray2[1] = "m";
        eF2.f$d = new ka<CF>(CF.f$M, stringArray2);
        eF.f$E(eF.f$d);
        eF.f$E(new Qe(eF));
    }

    public static ka f$E(EF eF) {
        return eF.f$d;
    }
}
package net.futureclient.client;

public enum eF {
    f$C,
    f$e,
    f$I,
    f$K,
    f$b,
    f$j,
    f$i,
    f$M,
    f$g;


    /*
     * WARNING - Possible parameter corruption
     * WARNING - void declaration
     */
    private eF() {
        eF eF2;
    }
}
package net.futureclient.client;

import net.futureclient.client.Ba;
import net.futureclient.client.Bh;
import net.futureclient.client.JD;
import net.futureclient.client.ka;
import net.futureclient.client.s;
import net.futureclient.client.uD;
import net.futureclient.client.yf;
import net.futureclient.client.z;
import net.minecraft.client.Minecraft;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemElytra;
import net.minecraft.item.ItemStack;

public class ef
extends Ba {
    private boolean f$d;
    private z<Boolean> f$j;
    private z<Boolean> f$b;
    private ka<yf> f$M;
    private s f$i;
    private Bh f$g;

    public static Minecraft f$E() {
        return f$d;
    }

    private boolean f$E(byte by) {
        int n;
        String string;
        ItemStack itemStack;
        int n2;
        if (0.f$d) {
            return false;
        }
        if (0.f$j.f$E().booleanValue() && by == 6) {
            Item item = ef.f$d.player.field_71069_bz.getSlot((int)by).getStack().getItem();
            if (item instanceof ItemElytra) {
                return false;
            }
            int n3 = n2 = 9;
            while (n3 <= 44) {
                itemStack = ef.f$d.player.field_71069_bz.getSlot(n2).getStack();
                if (itemStack != ItemStack.EMPTY && itemStack.getItem() instanceof ItemElytra && itemStack.getCount() == 1 && itemStack.getMaxDamage() - itemStack.getItemDamage() > 5) {
                    boolean bl;
                    boolean bl2 = bl = ef.f$d.player.field_71069_bz.getSlot((int)by).getStack() == ItemStack.EMPTY;
                    if (!bl) {
                        0.f$E(by, false);
                    }
                    0.f$E(n2, true);
                    if (!bl) {
                        0.f$E(n2, false);
                    }
                    return true;
                }
                n3 = n2 = (int)((byte)(n2 + 1));
            }
        }
        int n4 = -1;
        n2 = -1;
        itemStack = null;
        switch ((yf)((Object)0.f$M.f$E())) {
            case f$g: {
                while (false) {
                }
                string = "blast_protection";
                break;
            }
            default: {
                string = "protection";
            }
        }
        if (ef.f$d.player.field_71069_bz.getSlot((int)by).getStack() != ItemStack.EMPTY && ef.f$d.player.field_71069_bz.getSlot((int)by).getStack().getItem() instanceof ItemArmor) {
            itemStack = (ItemArmor)ef.f$d.player.field_71069_bz.getSlot((int)by).getStack().getItem();
            n4 = itemStack.damageReduceAmount + EnchantmentHelper.getEnchantmentLevel((Enchantment)Enchantment.getEnchantmentByLocation((String)string), (ItemStack)ef.f$d.player.field_71069_bz.getSlot((int)by).getStack());
        }
        int n5 = n = 9;
        while (n5 <= 44) {
            ItemStack itemStack2 = ef.f$d.player.field_71069_bz.getSlot(n).getStack();
            if (itemStack2 != ItemStack.EMPTY && itemStack2.getItem() instanceof ItemArmor && itemStack2.getCount() == 1) {
                ItemArmor itemArmor = (ItemArmor)itemStack2.getItem();
                int n6 = itemArmor.damageReduceAmount + EnchantmentHelper.getEnchantmentLevel((Enchantment)Enchantment.getEnchantmentByLocation((String)string), (ItemStack)itemStack2);
                if (0.f$E(itemArmor, by) && (itemStack == null || n4 < n6)) {
                    n4 = n6;
                    itemStack = itemArmor;
                    n2 = n;
                }
            }
            n5 = n = (int)((byte)(n + 1));
        }
        if (n2 != -1) {
            int n7 = n = ef.f$d.player.field_71069_bz.getSlot((int)by).getStack() == ItemStack.EMPTY ? 1 : 0;
            if (n == 0) {
                0.f$E(by, false);
            }
            0.f$E(n2, true);
            if (n == 0) {
                0.f$E(n2, false);
            }
            return true;
        }
        return false;
    }

    private boolean f$e(ItemArmor itemArmor) {
        return itemArmor.armorType == EntityEquipmentSlot.CHEST;
    }

    public ef() {
        ef ef2;
        String[] stringArray = new String[3];
        stringArray[0] = "AutoArmor";
        stringArray[1] = "aa";
        stringArray[2] = "armor";
        super("AutoArmor", stringArray, true, -5385072, JD.f$I);
        ef ef3 = ef2;
        String[] stringArray2 = new String[8];
        stringArray2[0] = "Open Inventory";
        stringArray2[1] = "OpenInventory";
        stringArray2[2] = "Open";
        stringArray2[3] = "Inv";
        stringArray2[4] = "Inventory";
        stringArray2[5] = "OpenInv";
        stringArray2[6] = "OE";
        stringArray2[7] = "I";
        ef3.f$b = new z<Boolean>(false, stringArray2);
        String[] stringArray3 = new String[4];
        stringArray3[0] = "Elytra Priority";
        stringArray3[1] = "ElytraPriority";
        stringArray3[2] = "Elytra";
        stringArray3[3] = "EP";
        ef2.f$j = new z<Boolean>(false, stringArray3);
        String[] stringArray4 = new String[2];
        stringArray4[0] = "Delay";
        stringArray4[1] = "D";
        ef2.f$i = new s((Number)Float.valueOf(0.35f), (Number)Float.valueOf(0.0f), (Number)Float.valueOf(1.0f), 0.01, stringArray4);
        String[] stringArray5 = new String[3];
        stringArray5[0] = "Priority";
        stringArray5[1] = "Prior";
        stringArray5[2] = "P";
        ef2.f$M = new ka<yf>(yf.f$M, stringArray5);
        ef2.f$g = new Bh();
        ef2.f$d = false;
        ef2.f$E(ef2.f$M, ef2.f$j, ef2.f$b, ef2.f$i);
        ef2.f$E(new uD(ef2));
    }

    public static Bh f$E(ef ef2) {
        return ef2.f$g;
    }

    public static Minecraft f$A() {
        return f$d;
    }

    private boolean f$E(ItemArmor itemArmor, byte by) {
        return by == 5 && 0.f$B(itemArmor) || by == 6 && 0.f$e(itemArmor) || by == 7 && 0.f$a(itemArmor) || by == 8 && 0.f$E(itemArmor);
    }

    public static Minecraft f$H() {
        return f$d;
    }

    public static Minecraft f$e() {
        return f$d;
    }

    private boolean f$E(ItemArmor itemArmor) {
        return itemArmor.armorType == EntityEquipmentSlot.FEET;
    }

    public static z f$a(ef ef2) {
        return ef2.f$b;
    }

    private boolean f$a(ItemArmor itemArmor) {
        return itemArmor.armorType == EntityEquipmentSlot.LEGS;
    }

    public static z f$E(ef ef2) {
        return ef2.f$j;
    }

    public static Minecraft f$h() {
        return f$d;
    }

    public static Minecraft f$K() {
        return f$d;
    }

    private void f$E(int n, boolean bl) {
        ef.f$d.playerController.windowClick(ef.f$d.player.field_71069_bz.windowId, n, 0, bl ? ClickType.QUICK_MOVE : ClickType.PICKUP, (EntityPlayer)ef.f$d.player);
    }

    public static boolean f$E(ef ef2, byte by) {
        return ef2.f$E(by);
    }

    private boolean f$B(ItemArmor itemArmor) {
        return itemArmor.armorType == EntityEquipmentSlot.HEAD;
    }

    public static s f$E(ef ef2) {
        return ef2.f$i;
    }

    public static Minecraft f$B() {
        return f$d;
    }

    public static void f$E(ef ef2, int n, boolean bl) {
        ef2.f$E(n, bl);
    }

    public static boolean f$E(ef ef2, boolean bl) {
        ef2.f$d = bl;
        return ef2.f$d;
    }

    public static Minecraft f$a() {
        return f$d;
    }
}
