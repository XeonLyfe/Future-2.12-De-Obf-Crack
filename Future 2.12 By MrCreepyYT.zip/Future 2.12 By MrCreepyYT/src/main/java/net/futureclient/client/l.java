package net.futureclient.client;

public interface l {
    public int getWindowId();
}
package net.futureclient.client;

import net.minecraft.util.EnumFacing;

public interface L {
    public void setPlacedBlockDirection(EnumFacing var1);
}
