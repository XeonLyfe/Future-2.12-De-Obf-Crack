package net.futureclient.client;

public interface t {
    public float getRainingStrength();

    public float getThunderingStrength();
}
