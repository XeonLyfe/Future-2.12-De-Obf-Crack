package net.futureclient.client;

import net.minecraft.inventory.IInventory;

public interface A {
    public IInventory getLowerChestInventory();
}
