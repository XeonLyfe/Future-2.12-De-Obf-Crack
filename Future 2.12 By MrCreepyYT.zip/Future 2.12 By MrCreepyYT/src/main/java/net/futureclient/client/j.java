package net.futureclient.client;

public interface j {
    public void f$E(Object ... var1);
}
package net.futureclient.client;

public interface J {
    public void f$E();

    public boolean f$E();

    public void f$E(boolean var1);
}
