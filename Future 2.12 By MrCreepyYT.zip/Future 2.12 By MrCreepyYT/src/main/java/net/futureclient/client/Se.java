package net.futureclient.client;

public enum Se {
    f$i,
    f$M,
    f$g;


    /*
     * WARNING - Possible parameter corruption
     * WARNING - void declaration
     */
    private Se() {
        Se se;
    }
}
package net.futureclient.client;

import net.futureclient.client.Ne;

public class SE
extends Ne {
    private final boolean f$g;
    private final boolean f$d;

    public boolean f$a() {
        SE sE;
        return sE.f$d;
    }

    public boolean f$e() {
        SE sE;
        return sE.f$g;
    }

    public SE(boolean bl, boolean bl2) {
        SE sE = 0;
        sE.f$g = bl;
        sE.f$d = bl2;
    }
}
package net.futureclient.client;

import net.futureclient.client.RF;
import net.futureclient.client.YE;

public class sE
extends RF {
    private YE f$d;
    private float f$g;

    public YE f$E() {
        sE sE2;
        return sE2.f$d;
    }

    public float f$E() {
        sE sE2;
        return sE2.f$g;
    }

    public sE(YE yE, float f) {
        sE sE2 = 0;
        sE2.f$d = yE;
        sE2.f$g = f;
    }
}
package net.futureclient.client;

import net.futureclient.client.De;
import net.futureclient.client.Ha;
import net.futureclient.client.vF;

public class se
extends Ha<De> {
    public final vF f$d;

    public se(vF vF2) {
        0.f$d = vF2;
    }

    @Override
    public void f$E(De de) {
        0.f$d.f$M = null;
    }
}
