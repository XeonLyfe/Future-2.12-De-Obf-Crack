package net.futureclient.client;

public interface f {
    public boolean isPrevOnGround();

    public void setHorseJumpPower(float var1);
}
package net.futureclient.client;

public interface F {
    public String f$E();
}
