package net.futureclient.client;

import java.util.List;
import net.futureclient.client.Ja;
import net.futureclient.client.O;
import net.minecraft.item.Item;

public final class n
extends O<Item> {
    public n(String ... stringArray) {
        super(stringArray, (Ja)null);
    }

    public n(List<Item> list, String ... stringArray) {
        super(list, stringArray, (Ja)null);
    }
}
