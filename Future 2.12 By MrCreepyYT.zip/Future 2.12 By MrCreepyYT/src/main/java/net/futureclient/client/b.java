package net.futureclient.client;

public interface b {
    public boolean isIsInWeb();
}
package net.futureclient.client;

import net.minecraft.item.ItemStack;

public interface B {
    public boolean f$E();

    public int f$E();

    public ItemStack getActiveItemStack();
}
