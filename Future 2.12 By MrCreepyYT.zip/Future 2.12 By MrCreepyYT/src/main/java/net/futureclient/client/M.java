package net.futureclient.client;

public interface M {
    public void invokeSyncCurrentPlayItem();

    public float getCurBlockDamageMP();
}
