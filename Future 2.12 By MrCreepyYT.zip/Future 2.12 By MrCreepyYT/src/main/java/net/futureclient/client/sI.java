package net.futureclient.client;

import net.futureclient.client.GA;
import net.futureclient.client.kH;

public class sI
extends GA {
    @Override
    public String f$E(String[] stringArray) {
        kH.f$E().f$E().f$E().forEach(ib -> ib.f$E(new Object[0]));
        return "Reloaded config.";
    }

    @Override
    public String f$E() {
        return null;
    }

    public sI() {
        sI sI2;
        String[] stringArray = new String[2];
        stringArray[0] = "Reload";
        stringArray[1] = "Load";
        super(stringArray);
    }
}
