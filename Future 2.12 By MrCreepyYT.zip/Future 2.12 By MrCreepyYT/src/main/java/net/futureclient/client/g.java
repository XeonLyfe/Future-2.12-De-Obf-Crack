package net.futureclient.client;

public interface g {
    public void f$a(Object ... var1);
}
package net.futureclient.client;

public interface G {
    public void setMotionZ(int var1);

    public void setMotionY(int var1);

    public void setMotionX(int var1);
}
