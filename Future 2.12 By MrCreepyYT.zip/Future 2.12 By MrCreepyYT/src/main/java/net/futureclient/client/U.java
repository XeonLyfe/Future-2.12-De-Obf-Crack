package net.futureclient.client;

import java.util.List;
import net.futureclient.client.Ja;
import net.futureclient.client.O;
import net.minecraft.block.Block;

public final class U
extends O<Block> {
    public U(List<Block> list, String ... stringArray) {
        super(list, stringArray, (Ja)null);
    }

    public U(String ... stringArray) {
        super(stringArray, (Ja)null);
    }
}
