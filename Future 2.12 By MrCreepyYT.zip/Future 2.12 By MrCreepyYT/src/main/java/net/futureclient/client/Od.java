package net.futureclient.client;

import net.futureclient.client.DA;
import net.futureclient.client.Ha;
import net.futureclient.client.Yf;

public class Od
extends Ha<Yf> {
    public final DA f$d;

    public Od(DA dA) {
        0.f$d = dA;
    }

    @Override
    public void f$E(Yf yf) {
        yf.f$E(0.f$d.f$I.f$E());
    }
}
package net.futureclient.client;

import net.futureclient.client.RF;

public class OD
extends RF {
    private String f$d;

    public OD(String string) {
        0.f$d = string.replaceAll("\u00a7.", "");
    }

    public String f$E() {
        OD oD;
        return oD.f$d;
    }
}
package net.futureclient.client;

import net.futureclient.client.RF;

public class oD
extends RF {
    public oD() {
        oD oD2;
    }
}
