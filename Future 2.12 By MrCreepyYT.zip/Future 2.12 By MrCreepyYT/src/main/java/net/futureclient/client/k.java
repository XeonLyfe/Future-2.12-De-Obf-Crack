package net.futureclient.client;

import net.minecraft.util.EnumHand;

public interface k {
    public void setHand(EnumHand var1);
}
package net.futureclient.client;

public interface K {
    public double getRenderPosZ();

    public double getRenderPosY();

    public double getRenderPosX();
}
