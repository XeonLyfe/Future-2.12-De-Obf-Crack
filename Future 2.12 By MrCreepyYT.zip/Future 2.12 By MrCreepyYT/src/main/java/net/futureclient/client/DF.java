package net.futureclient.client;

import net.futureclient.client.RF;

public class DF
extends RF {
    public DF() {
        DF dF;
    }
}
package net.futureclient.client;

import net.futureclient.client.yd;

public class Df {
    public static final int[] f$d;

    static {
        f$d = new int[yd.values().length];
        try {
            Df.f$d[yd.f$i.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Df.f$d[yd.f$M.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Df.f$d[yd.f$g.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
    }
}
package net.futureclient.client;

import net.futureclient.client.Xd;
import net.minecraft.util.math.AxisAlignedBB;

public class df
extends Xd {
    private float f$d;

    public void f$E(float f) {
        0.f$d = f;
    }

    public df(AxisAlignedBB axisAlignedBB, float f) {
        super(axisAlignedBB);
        0.f$d = f;
    }

    public float f$E() {
        df df2;
        return df2.f$d;
    }
}
package net.futureclient.client;

import net.futureclient.client.RF;

public class dF
extends RF {
    private String f$d;

    public void f$E(String string) {
        0.f$d = string;
    }

    public String f$E() {
        dF dF2;
        return dF2.f$d;
    }

    public dF(String string) {
        0.f$d = string;
    }
}
