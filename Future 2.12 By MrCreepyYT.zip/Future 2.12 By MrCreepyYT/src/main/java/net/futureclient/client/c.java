package net.futureclient.client;

public interface c {
    public boolean isIsWet();

    public void setIsWet(boolean var1);
}
package net.futureclient.client;

public interface C {
    public void setNotRenderingEffectsInGUI(boolean var1);
}
