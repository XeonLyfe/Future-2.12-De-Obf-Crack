package net.futureclient.client;

import net.futureclient.client.Ha;
import net.futureclient.client.RF;

public interface W {
    public void f$E();

    public void f$E(RF var1);

    public void f$a(Ha var1);

    public void f$E(Ha var1);
}
