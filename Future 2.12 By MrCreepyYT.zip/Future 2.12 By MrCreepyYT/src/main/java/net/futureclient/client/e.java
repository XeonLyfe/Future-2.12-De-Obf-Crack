package net.futureclient.client;

public interface e {
    public void setMotionZ(float var1);

    public void setMotionY(float var1);

    public void setMotionX(float var1);
}
package net.futureclient.client;

import net.minecraft.util.text.ITextComponent;
import org.apache.logging.log4j.Level;

public interface E {
    public void f$E(String var1, boolean var2);

    public void f$E(Level var1, String var2);

    public void f$E(ITextComponent var1, boolean var2);

    public void f$E(String var1);
}
