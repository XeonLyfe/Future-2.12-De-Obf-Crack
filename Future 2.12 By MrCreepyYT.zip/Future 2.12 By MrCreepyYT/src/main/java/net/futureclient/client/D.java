package net.futureclient.client;

public interface D {
    public void setY(double var1);

    public void setMoving(boolean var1);

    public void setRotating(boolean var1);

    public void setOnGround(boolean var1);

    public void setPitch(float var1);

    public boolean isMoving();

    public void setZ(double var1);

    public void setX(double var1);

    public boolean isRotating();

    public void setYaw(float var1);
}
