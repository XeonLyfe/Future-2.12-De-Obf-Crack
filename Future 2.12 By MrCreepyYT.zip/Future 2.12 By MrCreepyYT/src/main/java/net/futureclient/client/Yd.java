package net.futureclient.client;

import net.futureclient.client.RF;

public class Yd
extends RF {
    public Yd() {
        Yd yd;
    }
}
package net.futureclient.client;

import net.futureclient.client.Yd;

public final class YD
extends Yd {
    public YD() {
        YD yD;
    }
}
package net.futureclient.client;

public enum yd {
    f$i,
    f$M,
    f$g;


    /*
     * WARNING - Possible parameter corruption
     * WARNING - void declaration
     */
    private yd() {
        yd yd2;
    }
}
package net.futureclient.client;

public enum yD {
    f$i,
    f$M,
    f$g;


    /*
     * WARNING - Possible parameter corruption
     * WARNING - void declaration
     */
    private yD() {
        yD yD2;
    }
}
