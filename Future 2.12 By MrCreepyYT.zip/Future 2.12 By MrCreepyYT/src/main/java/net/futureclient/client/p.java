package net.futureclient.client;

import net.minecraft.potion.PotionEffect;

public interface p {
    public PotionEffect getPotionId();
}
package net.futureclient.client;

import net.minecraft.entity.player.EntityPlayer;

public interface P {
    public String f$E();

    public boolean f$E(EntityPlayer var1);
}
