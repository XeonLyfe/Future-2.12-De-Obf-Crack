package net.futureclient.client;

public interface i {
    public void invokeSetupCameraTransform(float var1, int var2);

    public void f$E(float var1);
}
package net.futureclient.client;

public interface I {
    public void setYaw(float var1);

    public void setPitch(float var1);
}
